import product from "../router/data.js";

  export const getallProduct = function (req, res) {
    res.json(product);
  }
  export const getproductbyid = function (req, res) {
    res.json({
      message: "get request",
    });
  }
  export  const createNewproduct =   function (req, res) {
    res.json({
      message: "get request",
    });
  }
  export  const updateproduct =  function (req, res) {
    res.json({
      message: "get request",
    });
  }
  export const deleteProduct =   function (req, res) {
    res.json({
      message: "get request",
    });
  }