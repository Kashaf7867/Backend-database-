
import express from 'express';
import { createNewproduct, deleteProduct, getallProduct, getproductbyid, updateproduct } from '../controller/Productcontroller.js';
const router = express.Router();

router.route('/products').get(getallProduct)
router.route('/products/id').get(getproductbyid)
router.route('/products').post(createNewproduct)
router.route('/products/id').put(updateproduct)
router.route('/products/id').delete(deleteProduct)

export default router;